package com.example.quentin.smartmiton.view.activities

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.quentin.smartmiton.R
import kotlinx.android.synthetic.main.activity_main.*

class Greeter(val name: String) {
    fun greet() {
        println("Hello, ${name}")
    }
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         setContentView(R.layout.activity_main)
      /*  basket.setOnClickListener {

            val intent: Intent = Intent(this, RecipesActivity::class.java)
            startActivity(intent)
        }*/
    }
}